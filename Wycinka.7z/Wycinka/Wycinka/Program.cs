﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Wycinka
{
    internal class Program
    {
        static void Main(string[] args)
        {

           // Dictionary<int, List<char>> gracze = new Dictionary<int, List<char>>();

            // pierwszy wiersz Input
            Console.WriteLine("Podaj liczbe Drzew oraz minimalny odstęp");

            var ciagLiczbaDrzewOdstep = Console.ReadLine();

            string[] rozdzieloneLiczbaDrzewOdstep = ciagLiczbaDrzewOdstep.Split(' ');

            int.TryParse(rozdzieloneLiczbaDrzewOdstep[0], out int liczbaDrzew);
            int.TryParse(rozdzieloneLiczbaDrzewOdstep[1], out int minOdstep);

            // drugi wiersz Input
            Console.WriteLine("Podaj Położenie kolejnych Drzew");

            var ciagPolozenieDrzew = Console.ReadLine();

            string[] polozenieDrzewaString = ciagPolozenieDrzew.Split(' ');

           // int.TryParse(polozenieDrzewaString[0], out int polozenieDrzewa);
            
            // drugi wiersz Input
            Console.WriteLine("Podaj Wysokość kolejnych Drzew");

            var ciagWysokoscDrzew = Console.ReadLine();

            string[] wysokoscDrzewaString = ciagWysokoscDrzew.Split(' ');

            // int.TryParse(wysokoscDrzewaString[0], out int wysokoscDrzew);

            List<Drzewa> ListaDrzew = new List<Drzewa>();
            List<int> Pozycje = new List<int>();
            List<Drzewa> DoWycinki = new List<Drzewa>();
            List<Drzewa> PorownanieWysokosci = new List<Drzewa>();
            int sumaWysokosci = 0;

            for (int i = 0; i < liczbaDrzew; i++)
            {
                Drzewa drzewo = new Drzewa();
                int.TryParse(polozenieDrzewaString[i], out int polozenieDrzewa);
                int.TryParse(wysokoscDrzewaString[i], out int wysokoscDrzewa);
                drzewo.ID = i + 1;
                drzewo.Pozycja = polozenieDrzewa;
                drzewo.Wysokosc = wysokoscDrzewa;
                drzewo.Bufor = polozenieDrzewa + minOdstep;
                ListaDrzew.Add(drzewo);
                DoWycinki.Add(drzewo);
                Pozycje.Add(drzewo.Pozycja);
                
                Console.WriteLine("Numer Drzewa: {0} Polozenie drzewa: {1} Wysokosc Drzewa: {2}, ", drzewo.ID, drzewo.Pozycja, drzewo.Wysokosc);
            }


            Console.WriteLine("Test 1");


            foreach (var drzewo in ListaDrzew)
            {
                foreach (var z in Pozycje)
                {
                    if (drzewo.Bufor < z)
                    {
                        DoWycinki.Remove(drzewo);
                        break;
                    }

                }



            



            



              
                   


                    //foreach (var z2 in PorownanieWysokosci)
                    //{
                    //    sumaWysokosci = +drzewo.Wysokosc;
                    //}

                    //foreach (var z2 in PorownanieWysokosci)
                    //{

                    //    if (drzewo.Wysokosc > sumaWysokosci - drzewo.Wysokosc)
                    //    {
                    //        DoWycinki.Remove(drzewo);
                    //        break;
                    //    }
                    //}
                
            }

            foreach (var tree in DoWycinki)
            {
                foreach (var z in Pozycje)
                {
                    if (tree.Bufor >= z)
                    {
                        sumaWysokosci += tree.Wysokosc;
                        break;
                    }
                    if (tree.Wysokosc >= sumaWysokosci - tree.Wysokosc)
                    {
                        DoWycinki.Remove(tree);
                        break;
                    }
                }
            }




            Console.WriteLine("Test porównanie wysokosci");

           Console.WriteLine(sumaWysokosci);

            Console.WriteLine("Koniec testu");

            Console.WriteLine("Test Główny!!!!!");

            foreach (var drzewo in DoWycinki)
            {
                Console.WriteLine(drzewo.ID);
            }


            

            Console.WriteLine("Koniec testu");

            Console.WriteLine();

            Console.WriteLine(ListaDrzew.ToArray());

            Console.WriteLine("query TEST");

            var query = ListaDrzew.Where(tree => tree.ID >= 1);

            foreach (var drzewo in query)
            {
                Console.WriteLine($"{drzewo.ID}, {drzewo.Pozycja}");
            }

            Console.WriteLine("Koniec");

            var zapytanieWycinka = ListaDrzew.Where(d => d.Bufor > d.Pozycja);

            foreach (var drzewo in zapytanieWycinka)
            {
                Console.WriteLine(drzewo.ID);
            }

            // liczba drzew minimalny odstęp
            //5 6
            // pozycje drzew
            //3 10 12 15 16
            //wysokosci
            //1 2 6 1 2


            //  6
            //3 10 12 15 16 25 35 36
            //1 2 6 1 2 1 1


            Console.ReadKey();
            
        }
    }






}
