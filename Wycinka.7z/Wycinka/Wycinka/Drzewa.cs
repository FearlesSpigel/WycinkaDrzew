﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Wycinka
{
    public class Drzewa
    {
        private int _iD;

        public int ID
        {
            get { return _iD; }
            set { _iD = value; }
        }

        private int _wysokosc;

        public int Wysokosc
        {
            get { return _wysokosc; }
            set { _wysokosc = value; }
        }

        private int _pozycja;

        public int Pozycja
        {
            get { return _pozycja; }
            set { _pozycja = value; }
        }

        private int _bufor;

        public int Bufor
        {
            get { return _bufor; }
            set { _bufor = value; }
        }







    }
}
